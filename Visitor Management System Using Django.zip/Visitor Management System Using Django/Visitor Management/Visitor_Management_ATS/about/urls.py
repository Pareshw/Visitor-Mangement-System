from django.contrib import admin
from django.urls import path
from about import views

urlpatterns = [
    
    path("", views.index, name='index'),
    path("home", views.index, name='home'),
    path("contact", views.contact,name='contact'),
    path("about", views.about, name='about'),
    path("user",views.user, name='user'),
    path("administrator",views.administrator, name='administrator'),
    path("visitor",views.visitor, name="visitor"),
    path("present_visitor",views.present_visitor, name="present_visitor"),
    path("out",views.out, name="out"),
    path("admingetinfo",views.admingetinfo, name="admingetinfo"),
    path("admingetsvisitors",views.admingetsvisitors, name="admingetsvisitors"),
    path("admingetinfobysearch",views.admingetinfobysearch, name="admingetinfobysearch")

]