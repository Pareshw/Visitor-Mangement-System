from django.contrib import admin
from about.models import Visitor

# Register your models here.

admin.site.register(Visitor)
