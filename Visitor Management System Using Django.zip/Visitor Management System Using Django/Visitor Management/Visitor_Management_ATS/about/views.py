from django.shortcuts import render
import time
import json
from django.contrib import messages
from about.models import Visitor
# Create your views here.
localtime = time.asctime(time.localtime(time.time()))
context = {"In_Time":f"{localtime}"}
all_members = Visitor.objects.all()
lott = time.localtime(time.time())
def index(request):
    messages.success(request, 'Welcome To Home Page')
    return render(request, "index.html")

def about(request):
    return render(request, "about.html")

def contact(request):
    return render(request, "contacts.html")

def user(request):
    return render(request, "user.html")

def administrator(request):
    if request.method == "POST":
        rp1 = request.POST.get("adminid")
        rp2 = request.POST.get("AdminPass")
        if rp1 == "master" and rp2 == "tiger": 
            return render(request, "admingetinfo.html") 
        else:
            pass
    return render(request, "administrator.html")

def visitor(request):
    if request.method == "POST":
        name = request.POST.get("name")
        phone = request.POST.get("phone")
        reason = request.POST.get("reason")
        intime = localtime
        outtime = "0"
        status = "In"
        v1 = time.localtime(time.time())
        ltt = [v1.tm_yday,v1.tm_mon,v1.tm_year]
        lt = json.dumps(ltt)
        visitor = Visitor(name = name, phone = phone, reason = reason, intime = intime, outtime = outtime, status=status , lt = lt)
        visitor.save()
        messages.success(request, "Visitor's Data Succesfully Saved")
        all_members = Visitor.objects.all()
        return render(request,"present_visitor.html",{'all':all_members})
    return render(request, "visitor_info.html",context)

def present_visitor(request):
    all_members = Visitor.objects.all()
    return render(request,"present_visitor.html",{'all':all_members})

def out(request):
    if request.method == "POST":
        ax = request.POST
        ay = [entry for entry in ax]
        all_members = Visitor.objects.all()
        for i in all_members:
            if str(i.id) == ay[1]:
                i.outtime = localtime
                i.status = "Out"
                i.save()
                messages.success(request, 'Visitor is Successfully Check-Out')
                all_members = Visitor.objects.all()
                return render(request,"present_visitor.html",{'all':all_members})
    return render(request,"visitor_info.html")


def admingetinfo(request):
    if request.method == "POST":
        ap = request.POST
        ad = [entry for entry in ap]
        all_members = Visitor.objects.all()
        k = []
        l = []
        q = []
        r = 0
        for i in all_members: 
            k = json.loads(i.lt)
            l.append(k)

        if ad[1] == "today":
            for i in all_members:
                if lott.tm_yday == l[r][0] and lott.tm_year == l[r][2]:
                    q.append(i)
                r += 1     

        elif ad[1] == "yesterday":
            for i in all_members:
                if lott.tm_yday-1 == l[r][0] and lott.tm_year == l[r][2]:
                    q.append(i)
                elif lott.tm_yday == 1 and lott.tm_year-1 == l[r][2]:
                    q.append(i)
                r += 1     

        elif ad[1] == "lastmonth":
            for i in all_members:
                if lott.tm_mon-1 == l[r][1] and lott.tm_year == l[r][2] and lott.tm_mon != 1:
                    q.append(i)
                elif lott.tm_mon == 1:
                    if 12 == l[r][1] and lott.tm_year-1 == l[r][2]:
                        q.append(i)
                r += 1

        elif ad[1] == "allreport":
            return render(request,"admingetsvisitors.html",{"allr":all_members})

    return render(request,"admingetsvisitors.html",{"allr":q})

def admingetsvisitors(request):
    return render(request,"admingetsvisitors.html")

def check(sdc):

    if sdc[1] == 2: 
        sdc[0] += 31

    elif sdc[1] == 3: 
        sdc[0] += 31+28

    elif sdc[1] == 4: 
        sdc[0] += 31+28+31

    elif sdc[1] == 5: 
        sdc[0] += 31+28+31+30

    elif sdc[1] == 6: 
        sdc[0] += 31+28+31+30+31

    elif sdc[1] == 7: 
        sdc[0] += 31+28+31+30+31+30

    elif sdc[1] == 8: 
        sdc[0] += 31+28+31+30+31+30+31

    elif sdc[1] == 9: 
        sdc[0] += 31+28+31+30+31+30+31+31

    elif sdc[1] == 10: 
        sdc[0] += 31+28+31+30+31+30+31+31+30

    elif sdc[1] == 11: 
        sdc[0] += 31+28+31+30+31+30+31+31+30+31

    elif sdc[1] == 12: 
        sdc[0] += 31+28+31+30+31+30+31+31+30+31+30

    return sdc

def admingetinfobysearch(request):
    if request.method == "POST":
    
        tl1 = []
        tl2 = []
        u = []
        v = []
        w = 0
        z = []
        all_members = Visitor.objects.all()

        tl1.append(int(request.POST.get("inputGroupSelect01")))
        tl1.append(int(request.POST.get("inputGroupSelect02")))
        tl1.append(int(request.POST.get("inputGroupSelect03")))
        tl2.append(int(request.POST.get("inputGroupSelect04")))
        tl2.append(int(request.POST.get("inputGroupSelect05")))
        tl2.append(int(request.POST.get("inputGroupSelect06")))

        for i in all_members: 
            u = json.loads(i.lt)
            v.append(u)

        y = [tuple(entry) for entry in v] 

        sdnl = check(tl1)
        ednl = check(tl2)

        sd = tuple(sdnl)
        ed = tuple(ednl)

        # Logic of the Program
        for i in all_members:
            if sd[2] <= y[w][2] <= ed[2]:
                if sd[1] <= y[w][1] <= ed[1]:
                    if sd[0] <= y[w][0] <= ed[0]:
                        z.append(i)
            w += 1
    return render(request,"admingetsvisitors.html",{"allr":z})
    